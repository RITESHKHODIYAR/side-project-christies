package PageClasses;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import baseClasses.PageBaseClass;

public class Departments extends PageBaseClass {

	public Departments(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
		
	}
}
