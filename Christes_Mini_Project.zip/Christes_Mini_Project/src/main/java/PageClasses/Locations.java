package PageClasses;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import baseClasses.PageBaseClass;

public class Locations extends PageBaseClass {

	public Locations(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
		
	}
}
