package PageClasses;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import baseClasses.PageBaseClass;

public class Services_page extends PageBaseClass {

	public Services_page(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
		
	}
}
